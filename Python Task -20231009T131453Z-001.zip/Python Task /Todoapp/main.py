from flask import Flask, request, jsonify
from flask_restplus import Resource, Api, fields
from flask_httpauth import HTTPBasicAuth
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
api = Api(app)
auth = HTTPBasicAuth()

users = {
    "admin": generate_password_hash("password"),
}

tasks = [
    {
        "id": 1,
        "title": "Buy groceries",
        "description": "Milk, Cheese, Pizza, Fruit, Tylenol",
        "done": False,
    },
    {
        "id": 2,
        "title": "Learn Python",
        "description": "Need to find a good Python tutorial on the web",
        "done": False,
    },
]

task_fields = api.model("Task", {
    "id": fields.Integer(readOnly=True, description="The unique id of the task"),
    "title": fields.String(required=True, description="The title of the task"),
    "description": fields.String(description="A description of the task"),
    "done": fields.Boolean(description="Whether or not the task is done"),
})

@auth.verify_password
def verify_password(username, password):
    if username in users:
        return check_password_hash(users.get(username), password)
    return False

class TaskList(Resource):
    @api.marshal_list_with(task_fields)
    def get(self):
        """Return a list of tasks"""
        return tasks

    @api.expect(task_fields)
    @api.marshal_with(task_fields, code=201)
    @auth.login_required
    def post(self):
        """Create a new task"""
        task = api.payload
        task["id"] = tasks[-1]["id"] + 1
        tasks.append(task)
        return task

class Task(Resource):
    @api.marshal_with(task_fields)
    def get(self, id):
        """Return a specific task"""
        return next((task for task in tasks if task["id"] == id), None)

    @api.expect(task_fields)
    @api.marshal_with(task_fields)
    @auth.login_required
    def put(self, id):
        """Update a specific task"""
        task = next((task for task in tasks if task["id"] == id), None)
        if task is None:
            api.abort(404, "Task not found")
        task.update(api.payload)
        return task

    @auth.login_required
    def delete(self, id):
        """Delete a specific task"""
        global tasks
        tasks = [task for task in tasks if task["id"] != id]
        return "", 204

api.add_resource(TaskList, "/tasks", endpoint="tasks")
api.add_resource(Task, "/tasks/<int:id>", endpoint="task")

if __name__ == "__main__":
    app.run(debug=True)