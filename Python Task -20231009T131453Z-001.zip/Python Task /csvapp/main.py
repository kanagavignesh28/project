
import csv
import operator

def read_csv(filename):
    students = []
    with open(filename, 'r') as file:
        reader = csv.reader(file)
        headers = next(reader)
        for row in reader:
            students.append(row)
    return headers, students

def find_topper(headers, students):
    toppers = {}
    for student in students:
        for i in range(1, len(student)):
            subject = headers[i]
            if subject not in toppers or float(student[i]) > toppers[subject][1]:
                toppers[subject] = (student[0], float(student[i]))
    return toppers

def find_top_three(headers, students):
    marks = []
    for student in students:
        total_marks = sum(float(mark) for mark in student[1:])
        marks.append((student[0], total_marks))
    marks.sort(key=lambda x: x[1], reverse=True)
    return marks[:3]

def main():
    filename = 'marks.csv'
    headers, students = read_csv(filename)

    toppers = find_topper(headers, students)
    top_three = find_top_three(headers, students)

    print("Topper in each subject:")
    for subject, student in toppers.items():
        print(f"{subject}: {student[0]} with marks {student[1]}")

    print("\nBest students in the class are:")
    for i, student in enumerate(top_three, 1):
        print(f"{i}. {student[0]} with total marks {student[1]}")

if __name__ == "__main__":
    main()